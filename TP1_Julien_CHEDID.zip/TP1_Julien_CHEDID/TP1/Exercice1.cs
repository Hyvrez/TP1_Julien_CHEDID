﻿using System;


namespace TP1
{
    public class Exercice1
    {
        private int _result;
        private General _general = new General();
        public void Initialise()
        {
            Console.WriteLine("1. For all the multiplication/ 2. Select only on table of multiplication");
            switch(_general.AskUserForParameter())
            {
                case 1:
                    Calcule();
                    break;
                case 2:
                    Calcul_N();
                    break;
                default:
                    Console.WriteLine("Stop to try to break the program pls");
                    break;
            }
        }

        private void Calcule()
        {
            for (int i = 1; i < 11; i++)
            {
                for (int j = 1; j < 11; j++)
                {
                    
                    this._result = j * i;
                    if (this._result %2 != 0)
                    {
                        Console.WriteLine(i + "*" + j + "=" + this._result);
                    }
                }
                
            }
        }


        private void Calcul_N()
        {
            Console.WriteLine("Select your number");
            int n = _general.AskUserForParameter();
            
            for (int i = 0; i <= n; i++)
            {
                Console.WriteLine(i+"*"+n+"="+i*n);
            }
        }


    }
}