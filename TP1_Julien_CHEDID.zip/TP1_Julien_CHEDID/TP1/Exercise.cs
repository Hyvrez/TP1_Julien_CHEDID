﻿namespace TP1
{
    public class Exercise
    {
        
    }
}