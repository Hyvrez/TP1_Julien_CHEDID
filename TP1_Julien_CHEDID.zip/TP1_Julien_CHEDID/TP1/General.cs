﻿using System;

namespace TP1
{
    public class General
    {
        public  int AskUserForParameter()
        { 
           
            int.TryParse(Console.ReadLine(), out var result);
            return result;
            
        }
        
        
    }
}