﻿using System;
using TP1.Properties;

namespace TP1
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            Exercice1 exercice1 = new Exercice1();
            Exercise2 exercise2 = new Exercise2();
            Exercise3 exercise3 = new Exercise3();
            Exercise4 exercise4 = new Exercise4();
            Exercise5 exercise5 = new Exercise5();
            General general = new General();
            Console.WriteLine("Choisissez votre exercice: ");
            

            switch (general.AskUserForParameter())
            {
                case 1:
                    Console.WriteLine("Exercice 1:");
                    exercice1.Initialise();
                    break;
                case 2 :
                    Console.WriteLine("Exercice 2:");
                    exercise2.Initialise();
                    break;
                case 3:
                    Console.WriteLine("Exercice 3:");
                    exercise3.ini_Exercice3();
                    break;
                case 4:
                    Console.WriteLine("Exercise 4:");
                    exercise4.Ini_exercice4();
                    break;
                case 5:
                    Console.WriteLine("Exercise 5:");
                    exercise5.Ini_exercise5();
                    break;
                default:
                    Console.WriteLine("Stop to try to break the program pls");
                    break;
            }
        }
    }
}