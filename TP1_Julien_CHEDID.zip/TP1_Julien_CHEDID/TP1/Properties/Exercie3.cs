﻿using System;

namespace TP1.Properties
{
    public class Exercise3
    {

        public void ini_Exercice3()
        {
            for (int i = -3; i < 4; i++)
            {
                try
                {

                    Console.WriteLine(10 / PowerFunction(i));

                }
                catch (DivideByZeroException)
                {
                    Console.WriteLine("Tentative to divide by 0");
                }
            }
        }

        private static int PowerFunction(int x)
        {
            return (int)(Math.Pow(x, 2) -4);
        }
    }
}