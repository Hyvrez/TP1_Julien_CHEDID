﻿using System;

namespace TP1.Properties
{
    public class Exercise2
    {
        public General General = new General();

        public void Initialise()
        {
            Console.WriteLine("1. Prime / 2. Fibonacci / 3. Factorial");
            switch (this.General.AskUserForParameter())
            {
                case 1:
                    Prime();
                    break;
                case 2:
                    Ini_Fibo();
                    break;
                case 3:
                    Console.WriteLine("Enter the number who you want to make the factorial");
                    Factorial(this.General.AskUserForParameter());
                    break;
                default:
                    Console.WriteLine("Stop to try to break the program pls");
                    break;
            }

        }

        private void Prime()
        {
            bool buff;
            for (int i = 1; i < 4; i++)
            {
                Console.WriteLine(i);
            }
            
            
            for (int i = 2; i <= 1000; i++)
            {
                buff = false;
                for (int j = 2; j <= Math.Sqrt(i); j++)
                {
                    if (i % j == 0)
                    {
                        buff = false;
                        break;
                    }
                    else if (i % j != 0)
                    {
                        buff = true;
                    }

                }

                if (buff)
                {
                    Console.WriteLine(i);
                }

            }
        }

        private void Ini_Fibo()
        {
            Console.WriteLine(" Choose one number for Fibo");
            int n = this.General.AskUserForParameter();
            for(int i=0;i<=n;i++) 
            {
                Console.WriteLine(i+"."+"  "+Fibonnaci(i));
            }
        }
        
        
        static int Fibonnaci(int n)
        {
            int buff2;
            if (n <= 0)
            {
                return 0;
            }
            if (n == 1)
            {
                return 1;
            }

            int buff = 0;
            int result = 1;

            for (int i = 2; i <= n; i++)
            {
                buff2 = buff + result;
                buff = result;
                result = buff2;
            }

            return result;
        }
        
        private void Factorial(int n)
        {
            int result = 1;

            if (n==0)
            {
                Console.WriteLine("1");
            }
            else if (n == 1)
            {
                Console.WriteLine("1");
            }
            else
            {
                for (int i = 1; i <= n; i++)
                {
                    result = result * i;
                }
            
                Console.WriteLine(result); 
            }
            
        }
    }

}