﻿using System;

namespace TP1.Properties
{
    public class Exercise4
    {
        private General General = new General();
        public void Ini_exercice4()
        {
            Console.WriteLine("Enter the value of n and m");
            int m = this.General.AskUserForParameter();
            int n = this.General.AskUserForParameter(); ;
            
            int buff = 0;

            for (int i = 1; i <= n; i++)
            {
                for (int j = 1; j <= m; j++)
                {
                    if((i==n & j==1)|(i==n & j == m)|(i==1 & j==1)){
                        Console.Write("0");
                    }
                    else if ((i==1 & j==m))
                    {
                        Console.WriteLine("0");
                    }

                    if (((i==1 | i == n) & j!=1 & j!= m))
                    {
                        Console.Write("-");
                    }
                    
                    if (((j == 1 | j == m) & i!=1 & i!= n))
                    {
                        if (j==1)
                        {
                            Console.Write("|");
                        }
                        else
                        {
                            Console.WriteLine("|");
                        }
                    }

                    if (i != 1 & j != 1 & i != n & j != m)
                    {
                        if (buff == 0)
                        {
                            Console.Write("*");
                            buff++;
                        }
                        else if (buff == 2)
                        {
                            Console.Write(" ");
                            buff = 0;
                        }
                        else
                        {
                            Console.Write(" ");
                            buff++;
                        }
                    }
                }
            }
            
        }
    }
}