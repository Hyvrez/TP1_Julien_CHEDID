﻿using System;

namespace TP1.Properties
{
    public class Exercise5
    {
        public void Ini_exercise5()
        {
            General general = new General();
            Console.WriteLine("1. Natural tree/ 2. Decorated tree");
            int choice = general.AskUserForParameter();
            switch (choice)
            {
                case 1:
                    Natural_tree();
                    break;
                case 2:
                    Decorated_tree();
                    break;
                default:
                    Console.WriteLine("Stop to try to break the program pls");
                    break;
            }

        }

        public void Natural_tree()
        {
            int n = 6;
            int buff = 1;
            
            for (int i = n; i > 0; i--)
            {
                for (int j = i; j > 0; j--)
                {
                    
                    if (j!=1)
                    {
                        Console.Write(" ");
                    }

                }

                for (int j = 1; j <= buff; j++)
                {
                    if (j!=buff)
                    {
                        Console.Write("*");
                    }
                    else
                    {
                        Console.WriteLine("*");
                    }
                }
                buff = buff + 2;
            }

            for (int i = 1; i <=n ; i++)
            {
                if (i==n-1)
                {
                    Console.Write("| |");
                }
                else
                {
                    Console.Write(" ");
                }
            }
        }

        public void Decorated_tree()
        {
            int n = 6;
            int buff = 1;
            Random random = new Random();
            int chance = random.Next(1, 101);
            for (int i = n; i > 0; i--)
            {
                for (int j = i; j > 0; j--)
                {
                    
                    if (j!=1)
                    {
                        Console.Write(" ");
                    }

                }

                for (int j = 1; j <= buff; j++)
                {
                    if (j!=buff)
                    {
                        chance = random.Next(1, 101);

                        if (chance<=10)
                        {
                            Console.Write("o");
                        }
                        else if (chance<=40 )
                        {
                            Console.Write("i");
                        }
                        else
                        {
                            Console.Write("*");
                        }
                        
                    }
                    else
                    {
                        if (chance<=10)
                        {
                            Console.WriteLine("o");
                        }
                        else if (chance<=40 )
                        {
                            Console.WriteLine("i");
                        }
                        else
                        {
                            Console.WriteLine("*");
                        }
                    }
                }
                buff = buff + 2;
            }

            for (int i = 1; i <=n ; i++)
            {
                if (i==n-1)
                {
                    Console.Write("| |");
                }
                else
                {
                    Console.Write(" ");
                }
            }
        }
    }
}